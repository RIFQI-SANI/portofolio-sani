# Portofolio Pribadi — Rifqi Sani

Website portofolio pribadi modern berorientasi **Clean & Minimalist Light**, responsif di semua ukuran layar (HP, Tablet, Laptop), semantik HTML5, aksesibel (WCAG), dan ramah SEO.

Dibuat khusus untuk **Rifqi Sani** — Mahasiswa Sistem Informasi di Universitas Tanjungpura (UNTAN) & Aspiring Software & Hardware Engineer.

---

## 📂 Struktur Proyek

```
portfolio-rifqi-sani/
├── index.html                 # Struktur utama halaman web (Semantic HTML5 & SEO)
├── assets/
│   ├── css/
│   │   └── style.css          # Tema Clean & Minimalist Light, CSS Variables, Responsive
│   ├── js/
│   │   └── main.js            # Interaktivitas (Salin email, scrollspy, menu mobile, toast)
│   └── images/
│       └── avatar.svg         # Avatar default berbasis SVG berinisial "RS"
└── README.md                  # Panduan penggunaan & kustomisasi
```

---

## 🚀 Cara Melihat Website di Browser

1. Buka folder:
   `C:\Users\Rifqi Sani\.gemini\antigravity\scratch\portfolio-rifqi-sani\`
2. Klik dua kali pada file [index.html](file:///C:/Users/Rifqi%20Sani/.gemini/antigravity/scratch/portfolio-rifqi-sani/index.html).
3. Website akan langsung terbuka di browser favorit Anda (Chrome, Edge, Firefox, dll) tanpa memerlukan instalasi aplikasi tambahan!

---

## 🛠️ Panduan Kustomisasi

### 1. Mengganti Foto Profil Asli
1. Siapkan foto profil Anda (format `.jpg` atau `.png`).
2. Masukkan file foto ke dalam folder `assets/images/` (misalnya diberi nama `foto-profil.jpg`).
3. Buka file [index.html](file:///C:/Users/Rifqi%20Sani/.gemini/antigravity/scratch/portfolio-rifqi-sani/index.html) pada bagian **Kartu Profil** (sekitar baris 112).
4. Ubah:
   ```html
   <img src="assets/images/avatar.svg" alt="Avatar Rifqi Sani" class="profile-image" id="profile-img">
   ```
   Menjadi:
   ```html
   <img src="assets/images/foto-profil.jpg" alt="Foto Rifqi Sani" class="profile-image" id="profile-img">
   ```

### 2. Memperbarui Username GitHub
Di bagian **Kontak** ([index.html](file:///C:/Users/Rifqi%20Sani/.gemini/antigravity/scratch/portfolio-rifqi-sani/index.html)), cari tautan GitHub:
```html
<a href="https://github.com/" target="_blank" ...>
```
Ganti `https://github.com/` dengan URL akun GitHub resmi Anda, contoh: `https://github.com/rifqisani`.

### 3. Menambahkan Proyek Unggulan Baru
Di bagian `#proyek`, sudah disediakan komentar template kode. Jika sudah memiliki proyek siap publikasi, cukup salin template tersebut dan isi:
- Nama Proyek
- Deskripsi singkat
- Tag teknologi (misal `C++`, `Python`, `Arduino`, `IoT`)
- Tautan Demo / Repository GitHub

---

## 🌐 Cara Hosting / Publikasi Online (Gratis)

### Opsi 1: GitHub Pages (Sangat Direkomendasikan)
1. Buat repositori baru di GitHub dengan nama misalnya `portfolio` atau `username.github.io`.
2. Unggah seluruh isi folder ini ke repositori tersebut.
3. Buka menu **Settings** > **Pages** di repositori GitHub Anda.
4. Pilih sumber build dari cabang `main` / root, lalu simpan.
5. Website Anda akan langsung online dan memiliki alamat publik seperti `https://username.github.io`!

---

## 💡 Rekomendasi Workspace
Untuk kenyamanan pengeditan selanjutnya, Anda disarankan untuk membuka folder ini sebagai **Active Workspace** di editor Anda:
`C:\Users\Rifqi Sani\.gemini\antigravity\scratch\portfolio-rifqi-sani`
