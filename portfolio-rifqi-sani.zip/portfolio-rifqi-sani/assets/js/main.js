/**
 * Portofolio Rifqi Sani - Interaktivitas Sederhana
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Tahun otomatis di footer
  const yearEl = document.getElementById('year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  // 2. Fungsi Salin Email & Toast
  const copyButtons = document.querySelectorAll('.copy-email-btn');
  const toast = document.getElementById('toast');
  const emailText = 'sanirifqi4@gmail.com';

  function showToast(msg) {
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, 2800);
  }

  copyButtons.forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      try {
        if (navigator.clipboard && window.isSecureContext) {
          await navigator.clipboard.writeText(emailText);
        } else {
          const ta = document.createElement('textarea');
          ta.value = emailText;
          ta.style.position = 'fixed';
          ta.style.opacity = '0';
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          ta.remove();
        }
        showToast('✓ Email disalin: ' + emailText);
      } catch (err) {
        showToast('Email: ' + emailText);
      }
    });
  });
});
